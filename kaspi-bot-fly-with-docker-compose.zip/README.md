# Kaspi Price Analyzer Bot 🤖

Telegram-бот для поиска товаров на [Kaspi.kz](https://kaspi.kz/shop/).

## 🚀 Возможности

- 🔎 Поиск по названию товара
- 💰 Вывод цены и названия
- 🔗 Ссылки на товары (до 3 штук)
- 👨‍💻 Не требует API, использует парсинг сайта

## 📦 Установка и запуск

### Через Railway (рекомендуется)

1. Нажмите кнопку ниже и следуйте инструкциям:

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/Wmmlki?referralCode=kaspi-bot)

2. Задайте переменную окружения `API_TOKEN` — это токен вашего Telegram-бота от [@BotFather](https://t.me/BotFather)

---

### Локальный запуск

```bash
git clone https://github.com/yourusername/kaspi-price-analyzer-bot.git
cd kaspi-price-analyzer-bot
pip install -r requirements.txt
export API_TOKEN=your_token_here
python bot/main.py
```

---

## 🧠 Используемые технологии

- Python 3.10+
- aiogram
- BeautifulSoup
- Railway (хостинг)

---

Проект для быстрого MVP без API Kaspi.
