import logging
import requests
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from bs4 import BeautifulSoup

API_TOKEN = "7770494035:AAFvo4wf0u_3SX7P4sIZRhqsUH0fY3iw96I"

logging.basicConfig(level=logging.INFO)
bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

def search_kaspi(query):
    url = f"https://kaspi.kz/shop/search/?text={query}"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")

    items = soup.select(".item-card__info")
    results = []
    for item in items[:3]:  # ограничим до 3 товаров
        title = item.select_one(".item-card__name").get_text(strip=True)
        price = item.select_one(".item-card__prices-price").get_text(strip=True)
        link = "https://kaspi.kz" + item.parent["href"]
        results.append(f"{title}
Цена: {price}
{link}")

    return "\n\n".join(results) if results else "Товары не найдены."

@dp.message_handler()
async def handle_message(message: types.Message):
    await message.reply("🔎 Ищу товары на Kaspi...")
    result = search_kaspi(message.text)
    await message.reply(result)

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
